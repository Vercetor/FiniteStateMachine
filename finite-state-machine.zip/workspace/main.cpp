//**********************************************************
// Colin Powers
// Analysis of Algorithms
// Finite State Machine
//**********************************************************

#include <fstream>
#include <iostream>

using namespace std;

// Function prototypes
int FSM(int RuleOne, char RuleTwo, string input); // This is where the finite state machine runs.

// Global constants for array
static const int number = 2;
static const int letter = 7;


//******************************************************************
// MAIN
//******************************************************************
int main()
{
    // True False on word existing.
    bool tf;
    
    // user input string to check against alphabet
    string input;
    
    // Declare 2 different arrays to hold file
    int RuleOne[number];
    char Ruletwo[letter];
    
    // Initialize array
    for(int ix = 0; ix < number; ix++)
        {
             RuleOne[ix] = 0;
            
        }// end of for loop
    for(int jx = 0; jx < letter; jx++)
            {
               RuleTwo[jx] = ' '; // left empty.
            }// end of for loop
    
    
    // Delcare input fule stream
    ifstream FSM_Rules;
    
    // Open the file
    FSM_Rules.open(Rules_FSM.txt);
    
    // Check the file was opened.
    if(!FSM_Rules)
    {
        cout << "File does not exist." << endl;
        exit(1); // call system stop.
    }
    
    // Read in the file
    while (FSM_Rules >> ix)
    {
        for(int ix = 0; ix < number; ix++)
        {
            for(int jx = 0; jx < letter; jx++)
            {
                Rules_FSM.txt >> number[ix];
                Rules_FSM.txt >> letter[jx];
            }// end of for loop
        }// end of for loop
    }// end of while loop
    
    // cout user menu
    cout << "*******************************************************************" << endl;
    cout << "Enter a word and I will check to see if it exists in this language." << endl;
    cout << "Please enter only a's and b's" << endl;
    cout << "*******************************************************************" << endl;
    cin >> input;
    
    FSM(int RuleOne, char RuleTwo, string input); // calls the finite state machine 
    
    // If bool TF returns true or false.
    if (tf == 1)
    {
        cout << "Congratz! Your word exists!!" << endl;
    }
    else
    {
        cout << "Sorry that word does not exist." << endl;
    }
    
    return 0;
}// END OF MAIN*****************************************************


//******************************************************************
// Finite State Machine
//******************************************************************
int FSM(int RuleOne, char RuleTwo, string input)
{
    //variables
    int rule1;      // for the input of digits of state number.
    char rule2;     // for the input of char state.
    bool tf;        // Returns 1 or 2 (True or False) if the word entered is in the rules.
    string input;   // user input.
    
// Accepting 6 states using switch
// Each case will represent a state in which the FSM exists.
// Recursively calls itself, while changing rule1's state so keep it flowing through the switch.
switch (rule1)
{
    case 1:
        if (rule2 == 'a')
        {
            int FSM(rule1 = 2); // changes to 'state 2' if 'a' is entered.
            tf = 1;
        }
        else if (rule2 == 'b')  // changes to 'state 3' if 'b' is entered.
        {
            int FSM(rule1 = 3);
            tf = 1;
        }
        else
        {
            cout << "does not exist."   // default incase incorrect char is entered.
            tf = 0;
        }
    break;
    
    case 2:
        if (rule2 == 'a')
            {
                int FSM(rule1 = 4); // changes to 'state 4' if 'a' is entered.
                tf = 1;
            }
            else if (rule2 == 'b')
            {
                int FSM(rule1 = 3); // changes to 'state 3' if 'b' is entered.
                tf = 1;
            }
            else
            {
                cout << "does not exist."   // default incase incorrect char is entered.
                tf = 0;
            }
    break;
    
    case 3:
        if (rule2 == 'a')
            {
                int FSM(rule1 = 5); // changes to 'state 5' if 'a' is entered.
                tf = 1;
            }
            else if (rule2 == 'b')
            {
                int FSM(rule1 = 6); // changes to 'state 6' if 'b' is entered.
                tf = 1;
            }
            else
            {
                cout << "does not exist."   // default incase incorrect char is entered.
                tf = 0;
            }
    break;
    
    case 4:
        if (rule2 == 'a')
            {
                int FSM(rule1 = 4); // changes back to 'state 4' if 'a' is entered.
                tf = 1;
            }
            else if (rule2 == 'b')
            {
                int FSM(rule1 = 2); // changes back to 'state 2' if 'b' is entered.
                tf = 1;
            }
            else
            {
                cout << "does not exist."   // default incase incorrect char is entered.
                tf = 0;
            }
    break;
    
    case 5:
        if (rule2 == 'a')
            {
                int FSM(rule1 = 5); // stays in 'state 5' if 'a' is entered.
                tf = 1;
            }
            else if (rule2 == 'b')
            {
                int FSM(rule1 = 5); // stays in 'state 5' if 'b' is entered.
                tf = 1;
            }
            else
            {
                cout << "does not exist."   // default incase incorrect char is entered.
                tf = 0;
            }
    break;
    
    case 6:
        if (rule2 == 'a')
            {
                int FSM(rule1 = 5); // changes to 'state 5' if 'a' is entered.
                tf = 1;
            }
            else if (rule2 == 'b')
            {
                int FSM(rule1 = 7); // changes to 'state 7' if 'b' is entered.
                tf = 1;
            }
            else
            {
                cout << "does not exist."   // default incase incorrect char is entered.
                tf = 0;
            }
    break;
    
    case 7:
        if (rule2 == 'a')
            {
                int FSM(rule1 = 4); // changes to 'state 4' if 'a' is entered.
                tf = 1;
            }
            else if (rule2 == 'b')
            {
                int FSM(rule1 = 7); // changes to 'state 3' if 'b' is entered.
                tf = 1;
            }
            else
            {
                cout << "does not exist."   // default incase incorrect char is entered.
                tf = 0;
            }
    break;
    
    default: "Does not exist."// user enters something not within a or b perimeters.
    tf = 0;
}

    return tf;
}// END OF FSM************************************************